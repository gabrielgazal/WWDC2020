//
//  ChordsCollectionViewCell.swift
//  PlaygroundWWDC2020
//
//  Created by Gabriel Gazal on 15/05/20.
//  Copyright © 2020 com.gazodia. All rights reserved.
//

import UIKit

@objc(BookCore_ChordsCollectionViewCell)
public class ChordsCollectionViewCell: UICollectionViewCell {
    @IBOutlet public weak var chordsName: UILabel!
    
}
