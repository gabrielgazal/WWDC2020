//
//  Chords.swift
//  PlaygroundWWDC2020
//
//  Created by Gabriel Gazal on 15/05/20.
//  Copyright © 2020 com.gazodia. All rights reserved.
//

import Foundation
import UIKit

class Chords{
    internal init(notasAcorde: [Int], nome: String) {
        self.notasAcorde = notasAcorde
        self.nome = nome
    }
    
    
    var notasAcorde: [Int]
    var nome: String
    
}
